'use strict'
var Common = require("./common"),
    Alipay = require("./lib/alipay"),
    Weixin = require("./lib/weixin"),
    fs = require('fs'),
    path = require('path'),
    debug  = require("debug")("third-payment");


class Lib {

  constructor(config){
    
    if(typeof config === "string"){
      try{
        if(!fs.existsSync(path.join(__dirname , config))){
          throw new Error("配置文件不存在");
        }
        var conf = fs.readFileSync(path.join(__dirname , config)).toString();
        conf = JSON.parse(conf);
        this.conf = conf;
      } catch(e) {
        debug(e);
        throw e;
      }
      
    }
    if(typeof config === "object"){
      this.conf = config;
    }

    if(!config){
      throw new Error("缺少支付参数配置")
    }


  };
  set conf(value){
    
    var verify = Common.vefiyConf(value)
    
    if(!verify){
      var err = Common.getErr();
      throw new Error(err);
    }
    this._conf =  value;
  };

  get conf(){
    return this._conf;
  }

  getChannel(type,vendor){
    switch(type){
      case "weixin_app" : 
      case "weixin_mp" : 
      case "weixin_native" : 
      case "weixin_web" :
        var temp = this.conf["weixin"];
        return  new Weixin(temp[vendor]);
        
      case "alipay_app" : 
      case "alipay_mp" : 
      case "alipay_web" :
      case "alipay_native" : 
        var temp = this.conf["alipay"];
        return new Alipay(temp[vendor]);

      default : 
        debug("支付类型错误: type");
        return false;
    }
  }

  /**
   * 获取预支付数据
   * @param {*  
   * type： “ weixin_mp ”， //weixin_app（微信APP）| 微信公众号 微信扫码 weixin_web（h5支付）| aliapy_app（支付宝APP）| alipay_web（支付宝网页）| alipay_mp（支付宝移动端）| aliapy_native（支付宝扫码）
   * vendor： “ official_account_1 ”，//公众号标识
   * description： “测试”，//商品描述
   * detail： “ 12222 ”，//商品详情
   * trade_id ： “ adfasdfasdf1242e ”， //商户订单号
   * amount： 100，//金额
   * notify_url ： “ https://callback.server.com/handle ”，    //第三方支付回调通知地址 
   * ip ： “ 127.0.0.1 ”，
   * openid ： “ oCLqdwT0fRFKcqKfmIezYOqpEHbk ”            // openid（微信公众号支付获取）} datas 
   */
  getPrePay(datas){
    var Channel = this.getChannel(datas.type,datas.vendor);
    if(!Channel){
      debug("支付类型错误: type");
      return Promise.reject("支付类型错误: type");
    }
    return Channel.create(datas);
  };

  /**
   * 校验第三方回调数据
   * 响应第三方回调数据请求体\格式可空（微信请求身体需要传xml）
   * @param {*} datas 数据
   * @param {*} response 响应
   * @param {*} format 格式
   */
  verifyResponse(datas,response,format){
    var Channel = this.getChannel(datas.type,datas.vendor);
    Channel.type = datas.type;
    return Channel.verifyResponse(response,format).then(
      res=>{
        if(res && res.result == true){
          return Channel.formatOut();
        }else{
          debug("verify response fail , ",res);
          return Channel.formatOut(res.msg || "数据校验错误");
        }
      }
    ).catch(err=>{
      debug("verify fail !",err);
      return Channel.formatOut(err);
    });
  }

  /**
   * 查询交易状态
   * @param {*} datas datas{type： “ weixin_mp ”，vender： “ official_account_1 ”}
   * @param {*} trade trade{ trade_no ：“平台交易号”，   //二选一 out_trade_no ：“商户交易号”   //二选一 }
   */
  queryTrade(datas,trade){
    var Channel = this.getChannel(datas.type,datas.vendor);
    Channel.type = datas.type;
    return Channel.query(trade);
  }

  /**
   * 退款操作
   * 
   * @param {*} trade { trade_no ：“平台交易号”，   //(二选一) out_trade_no ：“商户交易号”，   //(二选一) type：“ alipay_app ”，vender：“ app ”，out_request_no ： “部分退款  唯一ID ” //可选 
  }
   */
  refundTrade(trade){
    var Channel = this.getChannel(trade.type,trade.vendor);
    return Channel.refund(trade);
  }

  /**
   * 支付宝单笔账单
   * @param {*} datas 数据交易详情
   *  {
   *   out_biz_no ： “ 12233333 ”，    //商户交易ID 
   *   payee_type ： “ ALIPAY_USERID ”，   //收款方账户类型。可取值：1，ALIPAY_USERID：支付宝账号对应的支付宝唯一用户号。以2088开头的16位纯数字组成2，ALIPAY_LOGONID：支付宝登录号，支持邮箱和手机号格式 
   *   payee_account ： “ 3333333 ”，//收款方账户。与payee_type配合使用。付款方和收款方不能是同一个账户 
   *   amount   ： 0.1，//转账金额，单位：元。只支持2位小数，小数点前最大支持13位，金额必须大于等于0.1元。最大转账金额以实际签约的限额为准 
   *   payer_show_name   ：  “张三”，   //   付款方姓名
   *   remark   ：  “备注”  //备注 
   * }
   */
  transfer(datas){
    var Channel = this.getChannel("alipay_app","app");
    return Channel.transfer(datas);
  }


}
module.exports = Lib;